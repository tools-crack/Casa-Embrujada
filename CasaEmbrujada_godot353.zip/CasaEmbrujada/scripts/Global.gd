extends Node
# Autoload: ajustes del juego, audio, fuente pixel, transiciones y datos de niveles.

# ===== AJUSTES (cambialos para balancear el juego) =====
const BOO_FEAR = 38.0       # miedo que da un BUU (ESPACIO)
const BOO_RADIUS = 30.0     # alcance del BUU
const THROW_FEAR = 45.0     # miedo que da un objeto lanzado
const DARK_FEAR = 5.0       # miedo por segundo cuando el humano esta a oscuras
const LIGHT_CALM = 4.0      # miedo que se quita por segundo con luz
const LAMP_RADIUS = 36.0    # radio de luz de una lampara encendida

const FONT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!?:-+/%'()><= "

var level = 0
var score = 0
var best = 0
var last_level = 1
var font
var light_tex
var music_player
var sfx_players = []
var sfx = {}
var current_music = ""
var fade_rect
var fading = false
var levels = []


func _ready():
    randomize()
    _setup_input()
    _setup_font()
    _setup_light_tex()
    _setup_audio()
    _setup_fade()
    _build_levels()
    load_best()


# ------------------------------------------------------------ niveles
func _build_levels():
    levels = [
        {"name": "SALA", "time": 55, "bg": 0,
         "humans": [Vector2(30, 70), Vector2(96, 64)],
         "lamps": [Vector2(20, 52), Vector2(108, 52)],
         "props": [["vase", Vector2(46, 100)], ["chair", Vector2(90, 100)]]},
        {"name": "COCINA", "time": 60, "bg": 1,
         "humans": [Vector2(28, 66), Vector2(98, 70), Vector2(64, 96)],
         "lamps": [Vector2(18, 50), Vector2(110, 50), Vector2(64, 108)],
         "props": [["vase", Vector2(40, 90)], ["chair", Vector2(88, 94)], ["box", Vector2(64, 66)]]},
        {"name": "SOTANO", "time": 65, "bg": 2,
         "humans": [Vector2(24, 60), Vector2(104, 60), Vector2(40, 100), Vector2(90, 100)],
         "lamps": [Vector2(18, 50), Vector2(110, 50), Vector2(64, 106)],
         "props": [["vase", Vector2(40, 80)], ["chair", Vector2(88, 80)], ["box", Vector2(64, 64)], ["vase", Vector2(104, 100)]]},
    ]


func get_level(i):
    if i < levels.size():
        return levels[i]
    # modo infinito: se generan niveles cada vez mas dificiles
    var n = int(min(6, 3 + (i - 2) / 2))
    var hs = []
    for k in range(n):
        hs.append(Vector2(rand_range(24, 104), rand_range(56, 108)))
    return {"name": "INFINITO", "time": 55 + n * 3, "bg": i % 3, "humans": hs,
        "lamps": [Vector2(20, 52), Vector2(108, 52), Vector2(64, 106)],
        "props": [["vase", Vector2(40, 90)], ["chair", Vector2(88, 92)], ["box", Vector2(64, 70)], ["vase", Vector2(104, 100)]]}


# ------------------------------------------------------------ input
func _add_key(action, codes):
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    for c in codes:
        var ev = InputEventKey.new()
        ev.scancode = c
        InputMap.action_add_event(action, ev)


func _add_axis(action, axis, value):
    var ev = InputEventJoypadMotion.new()
    ev.axis = axis
    ev.axis_value = value
    InputMap.action_add_event(action, ev)


func _add_btn(action, btn):
    var ev = InputEventJoypadButton.new()
    ev.button_index = btn
    InputMap.action_add_event(action, ev)


func _setup_input():
    _add_key("left", [KEY_A, KEY_LEFT])
    _add_key("right", [KEY_D, KEY_RIGHT])
    _add_key("up", [KEY_W, KEY_UP])
    _add_key("down", [KEY_S, KEY_DOWN])
    _add_key("boo", [KEY_SPACE])
    _add_key("act", [KEY_E, KEY_Z])
    _add_key("restart", [KEY_R])
    _add_axis("left", 0, -1.0)
    _add_axis("right", 0, 1.0)
    _add_axis("up", 1, -1.0)
    _add_axis("down", 1, 1.0)
    _add_btn("boo", 0)
    _add_btn("act", 2)


# ------------------------------------------------------------ fuente pixel 3x5
func _setup_font():
    font = BitmapFont.new()
    var tex = load("res://art/font.png")
    font.add_texture(tex)
    font.height = 6
    font.ascent = 5
    for i in range(FONT_CHARS.length()):
        var code = FONT_CHARS.unicode_at(i)
        if FONT_CHARS[i] == " ":
            font.add_char(code, 0, Rect2(0, 0, 0, 0), Vector2(0, 0), 4)
        else:
            font.add_char(code, 0, Rect2(i * 4, 0, 3, 5), Vector2(0, 0), 4)


func make_label(text, pos, color = Color(1, 1, 1), scale = 1, align = Label.ALIGN_LEFT, width = 0):
    var l = Label.new()
    l.add_font_override("font", font)
    l.add_color_override("font_color", color)
    l.add_color_override("font_color_shadow", Color(0, 0, 0, 0.8))
    l.add_constant_override("shadow_offset_x", 1)
    l.add_constant_override("shadow_offset_y", 1)
    l.text = text.to_upper()
    l.align = align
    l.rect_position = pos
    l.rect_scale = Vector2(scale, scale)
    if width > 0:
        l.rect_size = Vector2(width, 6)
    return l


# ------------------------------------------------------------ luz (textura radial en bandas)
func _setup_light_tex():
    var img = Image.new()
    img.create(64, 64, false, Image.FORMAT_RGBA8)
    img.lock()
    for y in range(64):
        for x in range(64):
            var d = Vector2(x - 31.5, y - 31.5).length() / 32.0
            var a = clamp(1.0 - d, 0.0, 1.0)
            a = floor(a * 5.0) / 5.0
            img.set_pixel(x, y, Color(a, a, a, a))
    img.unlock()
    light_tex = ImageTexture.new()
    light_tex.create_from_image(img, 0)


# ------------------------------------------------------------ audio
func _setup_audio():
    music_player = AudioStreamPlayer.new()
    music_player.volume_db = -9.0
    add_child(music_player)
    for i in range(8):
        var p = AudioStreamPlayer.new()
        add_child(p)
        sfx_players.append(p)
    for n in ["boo", "lamp_off", "lamp_on", "throw", "break", "scare", "win", "lose", "select", "door", "giggle"]:
        sfx[n] = load("res://audio/%s.wav" % n)


func play_sfx(sname, vol = 0.0, pitch = 1.0):
    if not sfx.has(sname):
        return
    var chosen = null
    for p in sfx_players:
        if not p.playing:
            chosen = p
            break
    if chosen == null:
        chosen = sfx_players[0]
    chosen.stream = sfx[sname]
    chosen.volume_db = vol
    chosen.pitch_scale = pitch
    chosen.play()


func play_music(mname):
    if current_music == mname and music_player.playing:
        return
    current_music = mname
    var s = load("res://audio/%s.wav" % mname)
    if s is AudioStreamSample:
        s.loop_mode = AudioStreamSample.LOOP_FORWARD
        s.loop_begin = 0
        s.loop_end = int(s.data.size() / 2)
    music_player.stream = s
    music_player.play()


# ------------------------------------------------------------ transiciones
func _setup_fade():
    var layer = CanvasLayer.new()
    layer.layer = 100
    add_child(layer)
    fade_rect = ColorRect.new()
    fade_rect.color = Color(0, 0, 0, 1)
    fade_rect.rect_size = Vector2(128, 128)
    fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fade_rect.modulate = Color(1, 1, 1, 0)
    layer.add_child(fade_rect)


func goto(path):
    if fading:
        return
    fading = true
    var tw = Tween.new()
    add_child(tw)
    tw.interpolate_property(fade_rect, "modulate:a", 0.0, 1.0, 0.25, Tween.TRANS_LINEAR, Tween.EASE_IN)
    tw.start()
    yield(tw, "tween_all_completed")
    get_tree().change_scene(path)
    yield(get_tree().create_timer(0.08), "timeout")
    tw.interpolate_property(fade_rect, "modulate:a", 1.0, 0.0, 0.25, Tween.TRANS_LINEAR, Tween.EASE_OUT)
    tw.start()
    yield(tw, "tween_all_completed")
    tw.queue_free()
    fading = false


# ------------------------------------------------------------ record
func save_best():
    var f = File.new()
    if f.open("user://best.save", File.WRITE) == OK:
        f.store_32(best)
        f.close()


func load_best():
    var f = File.new()
    if f.file_exists("user://best.save") and f.open("user://best.save", File.READ) == OK:
        best = f.get_32()
        f.close()
