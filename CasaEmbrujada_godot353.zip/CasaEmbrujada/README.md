# CASA EMBRUJADA  (Godot 3.5.3)

Juegas como el FANTASMA. Los humanos son los enemigos: asustalos hasta que salgan corriendo por la puerta
antes de que se acabe el tiempo. Pixel art 128x128, hecho a mano (sin mucho detalle), con musica y sonidos.

## Como abrirlo
1. Descomprime el zip.
2. Godot 3.5.3 > Import > selecciona `project.godot`.
3. Espera a que importe los assets y pulsa F5.

## Controles
- WASD / Flechas ........ mover
- ESPACIO ............... BUU! (asusta a los humanos cerca; cuesta energia)
- E ..................... apagar/encender lampara cercana, o LANZAR un objeto cercano contra el humano mas cercano
- R ..................... reiniciar nivel      ESC: menu
- Mando: A = BUU, X = accion

## Mecanicas
- Cada humano tiene barra de miedo. A 100 huye por la puerta.
- A oscuras (fuera del radio de una lampara encendida) el miedo sube solo. Con luz baja.
- Los humanos vuelven a encender las lamparas apagadas. Apagalas otra vez!
- Los objetos (jarron, silla, caja) se lanzan y reaparecen a los 6 segundos.
- 3 niveles (SALA, COCINA, SOTANO) y despues MODO INFINITO, cada vez mas humanos.

## Balance rapido
Abre `scripts/Global.gd` y cambia las constantes de arriba (BOO_FEAR, DARK_FEAR, LAMP_RADIUS...).
Los niveles estan en `_build_levels()`.

## Estructura
- `scenes/`  Menu, Level, Ghost, Human, Lamp, Prop, HUD, Poof, GameOver
- `scripts/` un script por escena + Global.gd (autoload: audio, fuente, input, niveles)
- `art/`     PNG de sprites (16x16), fondos 128x128, fuente 3x5
- `audio/`   musica y efectos (WAV generados por codigo)

Si los sprites se ven borrosos: selecciona los PNG > pestaña Import > desactiva Filter > Reimport.
