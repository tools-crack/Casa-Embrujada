extends Node2D
# Particulas pixel cortas (se borra solo).

var parts = []
var t = 0.0
var col = Color(1, 1, 1)


func _ready():
    z_index = 15
    for i in range(10):
        var a = randf() * TAU
        parts.append({"p": Vector2.ZERO, "v": Vector2(cos(a), sin(a)) * rand_range(15.0, 45.0)})


func _process(delta):
    t += delta
    for p in parts:
        p["p"] += p["v"] * delta
    update()
    if t > 0.5:
        queue_free()


func _draw():
    var a = 1.0 - t / 0.5
    for p in parts:
        draw_rect(Rect2(p["p"].round(), Vector2(2, 2)), Color(col.r, col.g, col.b, a))
