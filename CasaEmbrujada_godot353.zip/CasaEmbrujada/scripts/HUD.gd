extends CanvasLayer
# Barra superior: tiempo, energia, nivel y humanos asustados. Mensajes grandes al centro.

const BAR_W = 36.0

var time_fill
var energy_fill
var lbl_level
var lbl_count
var band
var msg1
var msg2


func _rect(pos, size, color):
    var r = ColorRect.new()
    r.rect_position = pos
    r.rect_size = size
    r.color = color
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return r


func _ready():
    layer = 10
    add_child(_rect(Vector2(0, 0), Vector2(128, 8), Color(0.04, 0.03, 0.07)))
    add_child(Global.make_label("T", Vector2(1, 1), Color(0.8, 0.95, 0.7)))
    add_child(_rect(Vector2(5, 1), Vector2(BAR_W + 2, 6), Color(0.2, 0.15, 0.3)))
    time_fill = _rect(Vector2(6, 2), Vector2(BAR_W, 4), Color(0.45, 0.9, 0.5))
    add_child(time_fill)
    add_child(Global.make_label("E", Vector2(46, 1), Color(0.7, 0.85, 1.0)))
    add_child(_rect(Vector2(50, 1), Vector2(BAR_W + 2, 6), Color(0.2, 0.15, 0.3)))
    energy_fill = _rect(Vector2(51, 2), Vector2(BAR_W, 4), Color(0.5, 0.7, 1.0))
    add_child(energy_fill)
    lbl_level = Global.make_label("N1", Vector2(91, 1), Color(1, 0.85, 0.4))
    add_child(lbl_level)
    lbl_count = Global.make_label("0/0", Vector2(106, 1), Color(1, 1, 1))
    add_child(lbl_count)
    band = _rect(Vector2(0, 46), Vector2(128, 36), Color(0, 0, 0, 0.65))
    band.visible = false
    add_child(band)
    msg1 = Global.make_label("", Vector2(0, 50), Color(1, 0.9, 0.5), 2, Label.ALIGN_CENTER, 64)
    msg1.visible = false
    add_child(msg1)
    msg2 = Global.make_label("", Vector2(0, 70), Color(1, 1, 1), 1, Label.ALIGN_CENTER, 128)
    msg2.visible = false
    add_child(msg2)


func set_level(n):
    lbl_level.text = "N%d" % n


func set_values(tr, er, got, total):
    time_fill.rect_size.x = BAR_W * clamp(tr, 0.0, 1.0)
    time_fill.color = Color(0.45, 0.9, 0.5) if tr > 0.25 else Color(1.0, 0.35, 0.35)
    energy_fill.rect_size.x = BAR_W * clamp(er, 0.0, 1.0)
    lbl_count.text = "%d/%d" % [got, total]


func show_message(a, b = ""):
    band.visible = true
    msg1.text = a.to_upper()
    msg1.visible = true
    msg2.text = b.to_upper()
    msg2.visible = true


func hide_message():
    band.visible = false
    msg1.visible = false
    msg2.visible = false
