extends Node2D

const GhostScene = preload("res://scenes/Ghost.tscn")

var t = 0.0


func _ready():
    Global.play_music("music_menu")
    var record = Global.score > Global.best
    if record:
        Global.best = Global.score
        Global.save_best()
    add_child(Global.make_label("FIN DEL JUEGO", Vector2(0, 8), Color(1, 0.5, 0.5), 2, Label.ALIGN_CENTER, 64))
    add_child(Global.make_label("NIVEL ALCANZADO: %d" % Global.last_level, Vector2(0, 34), Color(1, 1, 1), 1, Label.ALIGN_CENTER, 128))
    add_child(Global.make_label("PUNTOS: %d" % Global.score, Vector2(0, 43), Color(1, 0.9, 0.4), 1, Label.ALIGN_CENTER, 128))
    add_child(Global.make_label("MEJOR: %d" % Global.best, Vector2(0, 52), Color(0.7, 0.8, 1.0), 1, Label.ALIGN_CENTER, 128))
    if record:
        add_child(Global.make_label("NUEVO RECORD!", Vector2(0, 61), Color(0.5, 1, 0.5), 1, Label.ALIGN_CENTER, 128))
    var g = GhostScene.instance()
    g.frozen = true
    g.scale = Vector2(2, 2)
    g.position = Vector2(64, 88)
    add_child(g)
    add_child(Global.make_label("ESPACIO: OTRA VEZ", Vector2(0, 108), Color(1, 0.9, 0.4), 1, Label.ALIGN_CENTER, 128))
    add_child(Global.make_label("ESC: MENU", Vector2(0, 116), Color(0.7, 0.7, 0.9), 1, Label.ALIGN_CENTER, 128))


func _process(delta):
    t += delta
    if t < 0.5:
        return
    if Input.is_action_just_pressed("boo") or Input.is_action_just_pressed("ui_accept"):
        set_process(false)
        Global.level = 0
        Global.score = 0
        Global.play_sfx("select")
        Global.goto("res://scenes/Level.tscn")
    elif Input.is_action_just_pressed("ui_cancel"):
        set_process(false)
        Global.goto("res://scenes/Menu.tscn")
