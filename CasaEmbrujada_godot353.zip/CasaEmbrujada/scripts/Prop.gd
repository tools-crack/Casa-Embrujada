extends Node2D
# Objeto embrujado: el fantasma lo lanza (E) contra un humano. Reaparece a los 6 segundos.

var kind = "vase"
var home = Vector2.ZERO
var state = "idle"      # idle, flying, hidden
var vel = Vector2.ZERO
var fly_t = 0.0
var respawn_t = 0.0
var near = false
var t = 0.0

onready var anim = $Anim


func setup(k, pos):
    kind = k
    home = pos
    position = pos
    t = randf() * 6.0
    anim.play(k)


func is_idle():
    return state == "idle"


func launch(target):
    state = "flying"
    vel = (target - position).normalized() * 125.0
    fly_t = 1.4
    Global.play_sfx("throw")


func _poof(c):
    var lvl = get_tree().current_scene
    if lvl.has_method("poof"):
        lvl.poof(position, c)


func _shatter():
    Global.play_sfx("break")
    _poof(Color(0.9, 0.8, 0.6))
    state = "hidden"
    visible = false
    respawn_t = 6.0


func _process(delta):
    t += delta
    match state:
        "idle":
            anim.position.y = round(sin(t * 2.5) * 1.5)
            anim.modulate = Color(1.5, 1.5, 1.5) if near else Color(1, 1, 1)
        "flying":
            position += vel * delta
            rotation += 14.0 * delta
            fly_t -= delta
            for h in get_tree().get_nodes_in_group("humans"):
                if h.can_be_hit() and position.distance_to(h.position) < 10.0:
                    h.add_fear(Global.THROW_FEAR)
                    _shatter()
                    return
            if fly_t <= 0.0 or position.x < 4 or position.x > 124 or position.y < 30 or position.y > 124:
                _shatter()
        "hidden":
            respawn_t -= delta
            if respawn_t <= 0.0:
                state = "idle"
                visible = true
                rotation = 0.0
                position = home
                _poof(Color(0.7, 0.85, 1.0))
