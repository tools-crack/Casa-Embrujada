extends Node2D
# Lampara: el fantasma la apaga/enciende con E. Los humanos tambien la vuelven a encender.

var on = true
var near = false
var radius = 36.0
var t = 0.0

onready var anim = $Anim
onready var light = $Light


func _ready():
    add_to_group("lamps")
    radius = Global.LAMP_RADIUS
    t = randf() * 6.0
    light.texture = Global.light_tex
    light.texture_scale = 1.25
    light.color = Color(1.0, 0.85, 0.5)
    light.energy = 1.1
    light.position = Vector2(0, -4)
    set_on(true, false)


func set_on(v, with_sound = true):
    on = v
    light.enabled = v
    if v:
        anim.play("on")
    else:
        anim.play("off")
    if with_sound:
        Global.play_sfx("lamp_on" if v else "lamp_off")
        var lvl = get_tree().current_scene
        if lvl.has_method("poof"):
            lvl.poof(position + Vector2(0, -4), Color(1, 0.9, 0.5) if v else Color(0.5, 0.5, 0.8))


func _process(delta):
    t += delta
    if on:
        light.energy = 1.1 + sin(t * 13.0) * 0.04 + sin(t * 5.3) * 0.04
    anim.modulate = Color(1.5, 1.5, 1.5) if near else Color(1, 1, 1)
