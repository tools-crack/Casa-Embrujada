extends Node2D
# Un humano. Se asusta con BUU, objetos y oscuridad. Cuando el miedo llega a 100 huye por la puerta.

signal escaped(h)

var variant = 0
var fear = 0.0
var state = "wait"      # wait, wander, flee, gone
var target = Vector2.ZERO
var wait_t = 0.5
var speed = 18.0
var shake_t = 0.0
var door_pos = Vector2(64, 38)
var lamp_target = null
var lit = true
var t = 0.0

onready var anim = $Anim


func _ready():
    add_to_group("humans")


func setup(v, pos, door):
    variant = v
    position = pos
    door_pos = door
    speed = rand_range(15.0, 21.0)
    wait_t = rand_range(0.3, 1.5)
    t = randf() * 5.0
    anim.flip_h = randf() < 0.5
    _play("idle")


func _play(n):
    var full = "%s_%d" % [n, variant]
    if anim.animation != full:
        anim.play(full)


func can_be_hit():
    return state != "gone" and state != "flee"


func boo_at(p):
    if position.distance_to(p) <= Global.BOO_RADIUS:
        add_fear(Global.BOO_FEAR)


func add_fear(a):
    if not can_be_hit():
        return
    fear = min(100.0, fear + a)
    shake_t = 0.7
    Global.play_sfx("scare", -3.0, rand_range(0.9, 1.25))
    var lvl = get_tree().current_scene
    if lvl.has_method("poof"):
        lvl.poof(position + Vector2(0, -8), Color(1, 1, 0.6))
    if fear >= 100.0:
        _start_flee()


func _start_flee():
    state = "flee"
    fear = 100.0
    shake_t = 0.0
    lamp_target = null
    _play("scared")


func _check_lit():
    lit = false
    for l in get_tree().get_nodes_in_group("lamps"):
        if l.on and position.distance_to(l.position) < Global.LAMP_RADIUS:
            lit = true
            return


func _pick_target():
    lamp_target = null
    var off = []
    for l in get_tree().get_nodes_in_group("lamps"):
        if not l.on:
            off.append(l)
    if off.size() > 0 and ((not lit) or randf() < 0.6):
        var best = off[0]
        for l in off:
            if l.position.distance_to(position) < best.position.distance_to(position):
                best = l
        lamp_target = best
        target = best.position + Vector2(rand_range(-4, 4), 10)
    else:
        target = Vector2(rand_range(14, 114), rand_range(46, 112))
    state = "wander"


func _process(delta):
    t += delta
    if state == "gone":
        return
    _check_lit()
    if state != "flee":
        anim.position.y = 0
        if lit:
            fear = max(0.0, fear - Global.LIGHT_CALM * delta)
        else:
            fear += Global.DARK_FEAR * delta
            if fear >= 100.0:
                _start_flee()
    if shake_t > 0.0 and state != "flee":
        shake_t -= delta
        _play("scared")
        anim.position.x = round(sin(t * 70.0))
        update()
        return
    anim.position.x = 0
    match state:
        "wait":
            _play("idle")
            wait_t -= delta
            if wait_t <= 0.0:
                _pick_target()
        "wander":
            if lamp_target != null and lamp_target.on:
                lamp_target = null
                state = "wait"
                wait_t = 0.3
            else:
                var d = target - position
                if d.length() < 2.0:
                    if lamp_target != null and not lamp_target.on:
                        lamp_target.set_on(true)
                    lamp_target = null
                    state = "wait"
                    wait_t = rand_range(0.6, 2.2)
                else:
                    position += d.normalized() * speed * delta
                    anim.flip_h = d.x < 0.0
                    _play("walk")
        "flee":
            var d2 = door_pos - position
            if d2.length() < 3.0:
                state = "gone"
                visible = false
                emit_signal("escaped", self)
            else:
                position += d2.normalized() * speed * 2.8 * delta
                anim.flip_h = d2.x < 0.0
                anim.position.y = -round(abs(sin(t * 16.0)) * 3.0)
    update()


func _draw():
    if state == "gone" or fear <= 0.5:
        return
    draw_rect(Rect2(-7, -13, 14, 3), Color(0, 0, 0, 0.7))
    draw_rect(Rect2(-6, -12, 12.0 * fear / 100.0, 1), Color(1.0, 1.0 - fear / 100.0 * 0.8, 0.2))
