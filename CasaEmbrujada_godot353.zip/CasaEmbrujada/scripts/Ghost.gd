extends Node2D
# El fantasma (jugador). Flechas/WASD = mover, ESPACIO = BUU, E = luz / lanzar objeto.

signal act

const SPEED = 60.0
const BOO_COST = 25.0
const REGEN = 16.0

var vel = Vector2.ZERO
var energy = 100.0
var frozen = false
var boo_t = 0.0
var ring_t = -1.0
var t = 0.0
var happy = false

onready var anim = $Anim
onready var light = $Light


func _ready():
    z_index = 10
    light.texture = Global.light_tex
    light.texture_scale = 0.75
    light.color = Color(0.7, 0.85, 1.0)
    light.energy = 0.9
    anim.play("float")


func use_energy(n):
    if energy >= n:
        energy -= n
        return true
    Global.play_sfx("select", -10.0, 0.5)
    return false


func set_happy(v):
    happy = v
    if v:
        anim.play("happy")
    else:
        anim.play("float")


func _physics_process(delta):
    t += delta
    if not frozen:
        var dir = Vector2(Input.get_action_strength("right") - Input.get_action_strength("left"),
                Input.get_action_strength("down") - Input.get_action_strength("up"))
        if dir.length() > 1.0:
            dir = dir.normalized()
        vel = vel.linear_interpolate(dir * SPEED, clamp(10.0 * delta, 0.0, 1.0))
        position += vel * delta
        position.x = clamp(position.x, 12.0, 116.0)
        position.y = clamp(position.y, 30.0, 116.0)
        energy = min(100.0, energy + REGEN * delta)
        if Input.is_action_just_pressed("boo") and boo_t <= 0.0:
            if use_energy(BOO_COST):
                _do_boo()
        if Input.is_action_just_pressed("act"):
            emit_signal("act")
    if boo_t > 0.0:
        boo_t -= delta
        if boo_t <= 0.0 and not happy:
            anim.play("float")
    if ring_t >= 0.0:
        ring_t += delta
        if ring_t > 0.4:
            ring_t = -1.0
        update()
    anim.position.y = round(sin(t * 4.0) * 1.5)
    anim.modulate = Color(1, 1, 1, 0.7 + 0.3 * energy / 100.0)


func _do_boo():
    boo_t = 0.45
    ring_t = 0.0
    anim.play("boo")
    Global.play_sfx("boo")
    get_tree().call_group("humans", "boo_at", position)


func _draw():
    if ring_t >= 0.0:
        var k = ring_t / 0.4
        draw_arc(Vector2.ZERO, 4.0 + k * Global.BOO_RADIUS, 0, TAU, 32, Color(1, 1, 1, 1.0 - k), 1.0)
