extends Node2D

const GhostScene = preload("res://scenes/Ghost.tscn")

var t = 0.0
var ghost
var prompt


func _ready():
    Global.play_music("music_menu")
    add_child(Global.make_label("CASA", Vector2(0, 6), Color(1, 0.85, 0.4), 2, Label.ALIGN_CENTER, 64))
    add_child(Global.make_label("EMBRUJADA", Vector2(0, 20), Color(0.75, 0.85, 1.0), 2, Label.ALIGN_CENTER, 64))
    ghost = GhostScene.instance()
    ghost.frozen = true
    ghost.scale = Vector2(2, 2)
    add_child(ghost)
    add_child(Global.make_label("WASD: MOVER   ESPACIO: BUU", Vector2(0, 88), Color(0.9, 0.9, 1.0), 1, Label.ALIGN_CENTER, 128))
    add_child(Global.make_label("E: LUZ / LANZAR OBJETO", Vector2(0, 95), Color(0.9, 0.9, 1.0), 1, Label.ALIGN_CENTER, 128))
    prompt = Global.make_label("PULSA ESPACIO", Vector2(0, 108), Color(1, 0.9, 0.4), 1, Label.ALIGN_CENTER, 128)
    add_child(prompt)
    add_child(Global.make_label("MEJOR: %d" % Global.best, Vector2(0, 121), Color(0.6, 0.6, 0.8), 1, Label.ALIGN_CENTER, 128))


func _process(delta):
    t += delta
    ghost.position = Vector2(64 + sin(t) * 12.0, 64 + cos(t * 0.7) * 4.0)
    prompt.visible = int(t * 2.0) % 2 == 0
    if Input.is_action_just_pressed("boo") or Input.is_action_just_pressed("ui_accept"):
        set_process(false)
        Global.level = 0
        Global.score = 0
        Global.play_sfx("select")
        Global.goto("res://scenes/Level.tscn")
