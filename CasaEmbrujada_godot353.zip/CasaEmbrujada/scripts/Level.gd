extends Node2D
# Un nivel: arma la casa, controla el tiempo y las condiciones de victoria/derrota.

const GhostScene = preload("res://scenes/Ghost.tscn")
const HumanScene = preload("res://scenes/Human.tscn")
const LampScene = preload("res://scenes/Lamp.tscn")
const PropScene = preload("res://scenes/Prop.tscn")
const HudScene = preload("res://scenes/HUD.tscn")
const PoofScene = preload("res://scenes/Poof.tscn")

const DOOR_TARGET = Vector2(64, 38)
const DARK_COLOR = Color(0.34, 0.3, 0.5)

onready var bg = $Background
onready var door = $Door
onready var world = $World
onready var dark = $Dark

var data
var ghost
var hud
var humans = []
var lamps = []
var props = []
var time_max = 60.0
var time_left = 60.0
var state = "intro"
var state_t = 0.0
var escaped_count = 0
var door_t = 0.0


func _ready():
    data = Global.get_level(Global.level)
    time_max = float(data["time"])
    time_left = time_max
    dark.color = DARK_COLOR
    bg.texture = load("res://art/bg%d.png" % int(data["bg"]))

    for p in data["lamps"]:
        var l = LampScene.instance()
        world.add_child(l)
        l.position = p
        lamps.append(l)

    for pr in data["props"]:
        var o = PropScene.instance()
        world.add_child(o)
        o.setup(pr[0], pr[1])
        props.append(o)

    var i = 0
    for p in data["humans"]:
        var h = HumanScene.instance()
        world.add_child(h)
        h.setup(i % 3, p, DOOR_TARGET)
        h.connect("escaped", self, "_on_escaped")
        humans.append(h)
        i += 1

    ghost = GhostScene.instance()
    ghost.frozen = true
    world.add_child(ghost)
    ghost.position = Vector2(64, 80)
    ghost.connect("act", self, "_on_act")

    hud = HudScene.instance()
    add_child(hud)
    hud.set_level(Global.level + 1)
    hud.show_message("NIVEL %d" % (Global.level + 1), str(data["name"]))

    Global.play_music("music_game")
    Global.play_sfx("giggle")


func poof(pos, color):
    var p = PoofScene.instance()
    p.position = pos
    p.col = color
    add_child(p)


func _nearest(list, maxd):
    var best = null
    var bd = maxd
    for n in list:
        if n.has_method("is_idle") and not n.is_idle():
            continue
        var d = n.position.distance_to(ghost.position)
        if d < bd:
            bd = d
            best = n
    return best


func _on_escaped(h):
    escaped_count += 1
    door_t = 0.8
    Global.play_sfx("door")


func _on_act():
    if state != "play":
        return
    var l = _nearest(lamps, 18.0)
    if l != null:
        if ghost.use_energy(6.0):
            l.set_on(not l.on)
        return
    var o = _nearest(props, 20.0)
    if o != null:
        var target = null
        var bd = 9999.0
        for h in humans:
            if h.can_be_hit():
                var d = h.position.distance_to(o.position)
                if d < bd:
                    bd = d
                    target = h
        if target != null and ghost.use_energy(18.0):
            o.launch(target.position)


func _process(delta):
    state_t += delta
    if Input.is_action_just_pressed("ui_cancel"):
        set_process(false)
        Global.goto("res://scenes/Menu.tscn")
        return
    if Input.is_action_just_pressed("restart") and state == "play":
        set_process(false)
        Global.goto("res://scenes/Level.tscn")
        return

    if door_t > 0.0:
        door_t -= delta
        door.frame = 1
    else:
        door.frame = 0

    match state:
        "intro":
            if state_t > 1.8:
                state = "play"
                state_t = 0.0
                ghost.frozen = false
                hud.hide_message()
        "play":
            time_left -= delta
            var nl = _nearest(lamps, 18.0)
            for l in lamps:
                l.near = (l == nl)
            var no = null
            if nl == null:
                no = _nearest(props, 20.0)
            for o in props:
                o.near = (o == no)
            if escaped_count >= humans.size():
                _win()
            elif time_left <= 0.0:
                _lose()
        "win":
            if state_t > 2.4:
                state = "done"
                Global.level += 1
                Global.goto("res://scenes/Level.tscn")
        "lose":
            if state_t > 2.4:
                state = "done"
                Global.goto("res://scenes/GameOver.tscn")

    hud.set_values(max(time_left, 0.0) / time_max, ghost.energy / 100.0, escaped_count, humans.size())


func _win():
    state = "win"
    state_t = 0.0
    ghost.frozen = true
    ghost.set_happy(true)
    var bonus = 100 * humans.size() + int(time_left) * 10
    Global.score += bonus
    Global.play_sfx("win")
    hud.show_message("CASA LIMPIA!", "+%d PUNTOS" % bonus)


func _lose():
    state = "lose"
    state_t = 0.0
    ghost.frozen = true
    Global.last_level = Global.level + 1
    Global.play_sfx("lose")
    hud.show_message("SE ACABO!", "LOS HUMANOS SE QUEDAN")
